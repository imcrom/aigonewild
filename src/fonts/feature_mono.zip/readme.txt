This font is distributed under a Creative Commons license.
The only condition for the free use of the font is the attribution in the form: Feature Mono developed by 
Anastasia Vrublevskaya at HSE ART AND DESIGN SCHOOL

Этот шрифт распространяется по лицензии Creative Commons.
Единственное условие бесплатного использования шрифта — это указание авторства в виде: Feature Mono разработан Анастасией Врублевской в Школе дизайна НИУ ВШЭ 

https://hsedesignlab.ru/hsefonts

